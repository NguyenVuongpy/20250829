import numpy as np
from typing import List, Dict, Tuple, Optional
from matplotlib.axes import Axes
import matplotlib.patches as mpatches
from controller.setting import Setting
from model.csv_database import CSV_Database
import pandas as pd
import math
from scipy import stats


class ControlSpecAnalyzer:
    """
    A utility class for analyzing and highlighting control spec violations in boxplots
    """
    
    def __init__(self):
        self.PINK_COLOR = "#FFB6C1"    # For CPK < 1.33
        self.ORANGE_COLOR = "#FFCC66"  # For median out of control
        self.YELLOW_COLOR = "#FFFF00"  # For excessive outliers (beyond sigma limits)
        self.RED_COLOR = "#FF0000"     # For multiple violations
        self.NORMAL_COLOR = "none"     # For normal boxplots
        self.has_any_violation = False
        self.violation_plots = set()
        
    def calculate_control_limits(self, data_list: List[np.ndarray], plot_item_name: str, ref_file: str = "None",
                                 database: CSV_Database = None, sigma_level: str = "±1.5σ") -> Tuple[float, float, float, float]:
        """
        Calculate control limits from reference data or current data
        Returns: (lower_limit, upper_limit, mean, std)
        """
        data_for_calculation = []
        if ref_file != "None" and database and plot_item_name:
            # Get data for plot_item_name from only the ref_file
            ref_plot_data = database.from_column(
                column=plot_item_name,
                removeNaN=True,
                sort_data_order_by=[ref_file]  # Only get data from ref_file
            )
            if ref_plot_data and ref_file in ref_plot_data and ref_plot_data[ref_file][0] == 'has_data':
                data_for_calculation.extend(ref_plot_data[ref_file][1])
        else:
            # If ref_file is None or invalid, use all available data for the current plot_item
            for data in data_list:
                if len(data) > 0:
                    data_for_calculation.extend(data)
        
        if len(data_for_calculation) == 0:
            return 0, 0, 0, 0
            
        mean = np.mean(data_for_calculation)
        std = np.std(data_for_calculation)
        
        # Extract sigma value from string
        if sigma_level == "±1.5σ":
            sigma_multiplier = 1.5
        elif sigma_level == "±2σ":
            sigma_multiplier = 2.0
        elif sigma_level == "±2.5σ":
            sigma_multiplier = 2.5
        elif sigma_level == "±3σ":
            sigma_multiplier = 3.0
        elif sigma_level == "±3.5σ":
            sigma_multiplier = 3.5
        else:
            sigma_multiplier = 1.5  # Default
        
        lower_limit = mean - sigma_multiplier * std
        upper_limit = mean + sigma_multiplier * std
        
        return lower_limit, upper_limit, mean, std
    
    def get_reference_data(self, plot_item_name: str, ref_file: str, database: CSV_Database) -> np.ndarray:
        """
        Get reference data for proportion comparison
        """
        if ref_file != "None" and database and plot_item_name:
            ref_plot_data = database.from_column(
                column=plot_item_name,
                removeNaN=True,
                sort_data_order_by=[ref_file]
            )
            if ref_plot_data and ref_file in ref_plot_data and ref_plot_data[ref_file][0] == 'has_data':
                return np.array(ref_plot_data[ref_file][1])
        return np.array([])
    
    def count_outliers_beyond_sigma(self, data: np.ndarray, lower_sigma: float, upper_sigma: float) -> int:
        """
        Count outliers beyond sigma limits (not whisker limits)
        """
        if len(data) == 0 or lower_sigma == 0 or upper_sigma == 0:
            return 0
            
        return np.sum((data < lower_sigma) | (data > upper_sigma))
    
    def two_sample_proportion_test(self, ref_data: np.ndarray, test_data: np.ndarray, 
                                 lower_sigma: float, upper_sigma: float,
                                 alpha: float = 0.05) -> bool:
        """
        Perform a two-sample proportion test to detect a significant difference in outlier proportions.
        Outliers are defined as points beyond sigma limits.
        Returns True if test_data has significantly more outliers than ref_data.
        """
        if len(ref_data) == 0 or len(test_data) == 0 or lower_sigma == 0 or upper_sigma == 0:
            return False
            
        # Count outliers in reference data (beyond sigma limits)
        ref_outliers = self.count_outliers_beyond_sigma(ref_data, lower_sigma, upper_sigma)
        ref_total = len(ref_data)
        ref_proportion = ref_outliers / ref_total if ref_total > 0 else 0
        
        # Count outliers in test data (beyond sigma limits)
        test_outliers = self.count_outliers_beyond_sigma(test_data, lower_sigma, upper_sigma)
        test_total = len(test_data)
        test_proportion = test_outliers / test_total if test_total > 0 else 0
        
        # Skip if no outliers in either group
        if ref_outliers == 0 and test_outliers == 0:
            return False
            
        # Skip if reference has no outliers but test has very few (to avoid false positives)
        if ref_outliers == 0 and test_outliers <= 1:
            return False
            
        # Minimum sample size requirement
        if ref_total < 10 or test_total < 10:
            return False
            
        # Perform two-sample proportion z-test
        try:
            # Pooled proportion
            pooled_prop = (ref_outliers + test_outliers) / (ref_total + test_total)
            
            # Standard error
            se = math.sqrt(pooled_prop * (1 - pooled_prop) * (1/ref_total + 1/test_total))
            
            # Z-score
            if se > 0:
                z_score = (test_proportion - ref_proportion) / se
                
                # One-tailed test (we only care if the test data has MORE outliers)
                p_value = 1 - stats.norm.cdf(z_score)
                
                return p_value < alpha
            else:
                return False
                
        except (ValueError, ZeroDivisionError):
            return False

    def analyze_and_highlight(self, ax: Axes, bp: dict, data_list: List[np.ndarray],
                              plot_item_name: str, plot_index: int = 0, lsl: float = None, usl: float = None,
                              ref_file: str = "None", database: CSV_Database = None,
                              sigma_level: str = "±1.5σ") -> bool:
        """
        Analyze boxplots and highlight control spec violations using statistical tests.
        Returns: True if any violations were found.
        """
        if not Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS:
            return False

        has_violation = False
        
        # Calculate control limits (for median check and outlier detection)
        lower_limit, upper_limit, mean, std = self.calculate_control_limits(
            data_list, plot_item_name, ref_file, database, sigma_level
        )
        
        # Get reference data for proportion comparison
        ref_data = self.get_reference_data(plot_item_name, ref_file, database)
        
        # Draw control spec lines if enabled
        if Setting.OPTS_SHOW_CONTROL_SPEC_LINES and lower_limit != 0 and upper_limit != 0:
            # Draw lower control limit line in orange
            ax.axhline(y=lower_limit, linewidth=0.5, color='orange', linestyle='--')
            # Add text for the lower control limit line - ONLY SHOW SIGMA LEVEL
            ax.text(ax.get_xlim()[1], lower_limit, sigma_level, 
                    verticalalignment='center', horizontalalignment='left',
                    color='orange', fontsize=6)
            
            # Draw upper control limit line in orange
            ax.axhline(y=upper_limit, linewidth=0.5, color='orange', linestyle='--')
            # Add text for the upper control limit line - ONLY SHOW SIGMA LEVEL
            ax.text(ax.get_xlim()[1], upper_limit, sigma_level, 
                    verticalalignment='center', horizontalalignment='left',
                    color='orange', fontsize=6)
        
        # Analyze each boxplot
        for i, data in enumerate(data_list):
            if len(data) == 0:
                continue
                
            color = self.NORMAL_COLOR
            violations = []
            
            # Check CPK violation
            if lsl is not None or usl is not None:
                mean = np.mean(data)
                std = np.std(data)
                if std > 0:
                    if usl is not None and lsl is not None:
                        if usl == 100:
                            cpk = (mean - lsl) / (3 * std)
                        elif usl == 0:
                            cpk = (mean - lsl) / (3 * std)
                        elif lsl == 0:
                            cpk = (usl - mean) / (3 * std)
                        else:
                            cpk = min((usl - mean) / (3 * std), (mean - lsl) / (3 * std))
                    elif usl is None and lsl is not None:
                        cpk = (mean - lsl) / (3 * std)
                    elif usl is not None and lsl is None:
                        cpk = (usl - mean) / (3 * std)
                    else:
                        cpk = None
                        
                    if cpk is not None and cpk < 1.33:
                        violations.append('cpk')
            
            # Check median violation (using sigma limits)
            if lower_limit != 0 and upper_limit != 0:
                median = np.median(data)
                if median < lower_limit or median > upper_limit:
                    violations.append('median')
            
            # Check outlier violation using two-sample proportion test (using sigma limits)
            if len(ref_data) > 0 and len(data) >= 10 and lower_limit != 0 and upper_limit != 0:
                
                has_excessive_outliers = self.two_sample_proportion_test(
                    ref_data, data, lower_limit, upper_limit, alpha=0.05
                )
                
                if has_excessive_outliers:
                    violations.append('outlier')
            
            # Set color based on violations
            if len(violations) >= 2:
                color = self.RED_COLOR
            elif 'cpk' in violations:
                color = self.PINK_COLOR
            elif 'median' in violations:
                color = self.YELLOW_COLOR
            elif 'outlier' in violations:
                color = self.ORANGE_COLOR
            
            # Apply highlighting
            if color != self.NORMAL_COLOR:
                box = bp['boxes'][i]
                box.set_facecolor(color)
                box.set_alpha(0.7)
                has_violation = True
                self.violation_plots.add(plot_index)
        
        if has_violation:
            self.has_any_violation = True
            
        return has_violation
    
    def is_plot_violation(self, plot_index: int) -> bool:
        """Check if the plot has a violation"""
        return plot_index in self.violation_plots
    
    def reset(self):
        """Reset the analyzer's state"""
        self.has_any_violation = False
        self.violation_plots.clear()
    
    def create_legend_elements(self):
        """Create legend elements for control spec violations"""
        elements = []
        
        if Setting.OPTS_HIGHLIGHT_CONTROL_SPEC_VIOLATIONS:
            elements.append(mpatches.Patch(facecolor=self.PINK_COLOR, alpha=0.9, label='CPK < 1.33'))
            elements.append(mpatches.Patch(facecolor=self.YELLOW_COLOR, alpha=0.9, label='Med Out σ Line'))
            elements.append(mpatches.Patch(facecolor=self.ORANGE_COLOR, alpha=0.9, label='Excessive Outliers'))
            elements.append(mpatches.Patch(facecolor=self.RED_COLOR, alpha=0.9, label='Multiple Violations'))
        
        return elements
    
    def add_legend(self, ax: Axes):
        """Add a legend to the plot"""
        if self.has_any_violation:
            legend_elements = self.create_legend_elements()
            
            if legend_elements:
                # Calculate legend position
                bbox = ax.get_position()
                # Reduce plot width to make space for the legend
                ax.set_position([bbox.x0, bbox.y0, bbox.width * 0.85, bbox.height])
                
                # Add legend outside the plot
                ax.legend(handles=legend_elements,
                          loc='center left',
                          bbox_to_anchor=(1.02, 0.5),
                          fontsize=8,
                          title='Control Spec Violations',
                          title_fontsize=9,
                          framealpha=0.8,
                          edgecolor='gray',
                          borderpad=0.5,
                          handletextpad=0.5,
                          labelspacing=0.5)